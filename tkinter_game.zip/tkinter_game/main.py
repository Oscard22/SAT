# SAT - EVAL N°6
# Abraham Chacon - 0801
# Oscar Mencias - 0801
# César Suniaga - 0801
# Emilio Vera - 0801

import random
import json
import tkinter as tk
from tkinter import ttk, messagebox

class JuegoLaberintoGUI:
    def __init__(self, root, preguntas):
        self.root = root
        self.root.title("Laberinto Mágico - Búsqueda del Tesoro")
        self.root.geometry("800x750")
        self.root.configure(bg="#2C3E50")
        
        # Constantes de diseño
        self.CELL_SIZE = 30
        self.COLOR_PARED = "#34495E"
        self.COLOR_CAMINO = "#ECF0F1"
        self.COLOR_JUGADOR = "#2ECC71"
        self.COLOR_SALIDA = "#E74C3C"
        self.COLOR_PREGUNTA = "#F1C40F"
        self.COLOR_RESPONDIDA = "#27AE60"
        
        # Configuración del laberinto
        self.laberinto = [
            "████████████████████",
            "█P                 █",
            "█ █ ███ ██████ ██  █",
            "█ █      █     █   █",
            "█ ███████ ███ █  ██",
            "█      █  █ █ █   █",
            "██████ ███  █ █  ██",
            "█             █   █",
            "█ █ ███ ███████ █ █",
            "█ █   █      █  █ █",
            "█ █████ ███ ███ █ █",
            "█            █  █  █",
            "█████ █████████ ███",
            "█                 █",
            "█ ████████████ ██ █",
            "█ █     ██     █  █",
            "█ ██ █████ ███ ██ █",
            "█    █S        █  █",
            "████ ███████████ ██",
            "████████████████████"
        ]
        
        self.preguntas = preguntas
        
        self.posicion_preguntas = [
            (3, 2), (15, 4), (8, 7), (12, 9), (5, 12),
            (17, 14), (10, 16), (4, 18), (14, 15), (7, 10)
        ]
        
        self.reiniciar_variables()
        self.configurar_interfaz()
        self.dibujar_laberinto()
        
        # Eventos de teclado
        self.root.bind('<Key>', self.procesar_tecla)
        
    def reiniciar_variables(self):
        self.jugador_x = 1
        self.jugador_y = 1
        self.preguntas_respondidas = set()
        self.historial_movimientos = [(1, 1)]
        self.pasos = 0
        self.juego_activo = True
        self.en_replay = False

    def configurar_interfaz(self):
        # Panel superior para estadísticas
        self.panel_stats = tk.Frame(self.root, bg="#34495E", pady=10)
        self.panel_stats.pack(fill=tk.X)
        
        self.lbl_titulo = tk.Label(self.panel_stats, text="🏃 LABERINTO MÁGICO 🏃", font=("Helvetica", 16, "bold"), bg="#34495E", fg="white")
        self.lbl_titulo.pack()
        
        self.lbl_stats = tk.Label(self.panel_stats, text="Pasos: 0 | Puntuación: 0", font=("Helvetica", 12), bg="#34495E", fg="#F1C40F")
        self.lbl_stats.pack()

        self.lbl_info = tk.Label(self.panel_stats, text="Usa W, A, S, D para moverte. Presiona 'E' sobre un '?' para responder.", font=("Helvetica", 10), bg="#34495E", fg="#BDC3C7")
        self.lbl_info.pack()
        
        # Lienzo (Canvas) para el laberinto
        ancho_canvas = len(self.laberinto[0]) * self.CELL_SIZE
        alto_canvas = len(self.laberinto) * self.CELL_SIZE
        
        self.frame_canvas = tk.Frame(self.root, bg="#2C3E50")
        self.frame_canvas.pack(expand=True)
        
        self.canvas = tk.Canvas(self.frame_canvas, width=ancho_canvas, height=alto_canvas, bg=self.COLOR_CAMINO, highlightthickness=0)
        self.canvas.pack(pady=20)

    def dibujar_laberinto(self, modo_mapa=False):
        self.canvas.delete("all")
        
        for y, fila in enumerate(self.laberinto):
            for x, caracter in enumerate(fila):
                x1 = x * self.CELL_SIZE
                y1 = y * self.CELL_SIZE
                x2 = x1 + self.CELL_SIZE
                y2 = y1 + self.CELL_SIZE
                
                # Dibujar paredes y fondo
                if caracter == '█':
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill=self.COLOR_PARED, outline="")
                else:
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill=self.COLOR_CAMINO, outline="#E0E0E0")
                
                # Dibujar salida
                if caracter == 'S':
                    self.canvas.create_rectangle(x1, y1, x2, y2, fill=self.COLOR_SALIDA, outline="")
                    self.canvas.create_text(x1 + self.CELL_SIZE/2, y1 + self.CELL_SIZE/2, text="S", fill="white", font=("Helvetica", 12, "bold"))
                
                # Dibujar preguntas
                if (x, y) in self.posicion_preguntas:
                    if (x, y) in self.preguntas_respondidas:
                        self.canvas.create_rectangle(x1, y1, x2, y2, fill=self.COLOR_RESPONDIDA, outline="")
                        self.canvas.create_text(x1 + self.CELL_SIZE/2, y1 + self.CELL_SIZE/2, text="✓", fill="white", font=("Helvetica", 12, "bold"))
                    else:
                        self.canvas.create_rectangle(x1, y1, x2, y2, fill=self.COLOR_PREGUNTA, outline="")
                        texto = f"P{self.posicion_preguntas.index((x,y))+1}" if modo_mapa else "?"
                        self.canvas.create_text(x1 + self.CELL_SIZE/2, y1 + self.CELL_SIZE/2, text=texto, fill="black", font=("Helvetica", 12, "bold"))

        # Dibujar jugador si no estamos viendo solo el mapa
        if not modo_mapa:
            jx1 = self.jugador_x * self.CELL_SIZE + 5
            jy1 = self.jugador_y * self.CELL_SIZE + 5
            jx2 = jx1 + self.CELL_SIZE - 10
            jy2 = jy1 + self.CELL_SIZE - 10
            self.canvas.create_oval(jx1, jy1, jx2, jy2, fill=self.COLOR_JUGADOR, outline="#27AE60", width=2)
            
        self.actualizar_estadisticas()

    def actualizar_estadisticas(self):
        puntos = len(self.preguntas_respondidas) * 10
        self.lbl_stats.config(text=f"Pasos: {self.pasos} | Puntuación: {puntos} | Respondidas: {len(self.preguntas_respondidas)}/{len(self.preguntas)}")

    def procesar_tecla(self, event):
        if not self.juego_activo or self.en_replay:
            return
            
        tecla = event.char.lower()
        
        dx, dy = 0, 0
        if tecla == 'w': dy = -1
        elif tecla == 's': dy = 1
        elif tecla == 'a': dx = -1
        elif tecla == 'd': dx = 1
        elif tecla == 'e':
            self.intentar_responder()
            return
            
        if dx != 0 or dy != 0:
            self.mover(dx, dy)

    def mover(self, dx, dy):
        nueva_x = self.jugador_x + dx
        nueva_y = self.jugador_y + dy
        
        if 0 <= nueva_x < len(self.laberinto[0]) and 0 <= nueva_y < len(self.laberinto):
            if self.laberinto[nueva_y][nueva_x] != '█':
                self.jugador_x = nueva_x
                self.jugador_y = nueva_y
                self.pasos += 1
                self.historial_movimientos.append((self.jugador_x, self.jugador_y))
                self.dibujar_laberinto()
                
                # Comprobar victoria
                if self.laberinto[self.jugador_y][self.jugador_x] == 'S':
                    self.juego_activo = False
                    self.mostrar_menu_victoria()
                
                # Avisar si hay pregunta
                elif (self.jugador_x, self.jugador_y) in self.posicion_preguntas:
                    if (self.jugador_x, self.jugador_y) not in self.preguntas_respondidas:
                        self.lbl_info.config(text="¡Pregunta encontrada! Presiona 'E' para responder.", fg="#F1C40F")
                    else:
                        self.lbl_info.config(text="Ya respondiste esta pregunta.", fg="#BDC3C7")
                else:
                    self.lbl_info.config(text="Usa W, A, S, D para moverte. Presiona 'E' sobre un '?' para responder.", fg="#BDC3C7")

    def intentar_responder(self):
        pos_actual = (self.jugador_x, self.jugador_y)
        if pos_actual in self.posicion_preguntas:
            idx = self.posicion_preguntas.index(pos_actual)
            if pos_actual not in self.preguntas_respondidas:
                self.abrir_ventana_pregunta(idx)
            else:
                messagebox.showinfo("Información", "Ya respondiste a esta pregunta correctamente.")
        else:
            self.lbl_info.config(text="No hay ninguna pregunta en esta casilla.", fg="#E74C3C")

    def abrir_ventana_pregunta(self, idx):
        pregunta = self.preguntas[idx]
        
        ventana_preg = tk.Toplevel(self.root)
        ventana_preg.title("¡Pregunta Encontrada!")
        ventana_preg.geometry("450x350")
        ventana_preg.configure(bg="#2C3E50")
        ventana_preg.transient(self.root)
        ventana_preg.grab_set() # Bloquea la ventana principal
        
        # Centrar ventana
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 225
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 175
        ventana_preg.geometry(f"+{x}+{y}")
        
        tk.Label(ventana_preg, text="📝 PREGUNTA", font=("Helvetica", 14, "bold"), bg="#2C3E50", fg="#F1C40F").pack(pady=10)
        
        # Texto de la pregunta con ajuste de línea
        lbl_preg = tk.Label(ventana_preg, text=pregunta["pregunta"], font=("Helvetica", 12), bg="#2C3E50", fg="white", wraplength=400, justify="center")
        lbl_preg.pack(pady=10)
        
        tk.Label(ventana_preg, text=f"💡 Pista: {pregunta['pista']}", font=("Helvetica", 10, "italic"), bg="#2C3E50", fg="#BDC3C7").pack(pady=5)
        
        frame_respuestas = tk.Frame(ventana_preg, bg="#2C3E50")
        frame_respuestas.pack(pady=15, fill=tk.BOTH, expand=True)
        
        def verificar(respuesta_usuario):
            correcta = pregunta.get("correcta")
            if respuesta_usuario.lower().strip() == correcta.lower().strip():
                messagebox.showinfo("¡Correcto!", "¡Respuesta correcta! +10 puntos", parent=ventana_preg)
                self.preguntas_respondidas.add(self.posicion_preguntas[idx])
                self.dibujar_laberinto()
                ventana_preg.destroy()
            else:
                messagebox.showerror("Incorrecto", "Respuesta incorrecta. ¡Inténtalo de nuevo!", parent=ventana_preg)
        
        # Generar controles según tipo
        if pregunta["tipo"] == "opcion_multiple":
            for opcion in pregunta["opciones"]:
                letra = opcion[0] # Extraer a, b, c, d
                btn = ttk.Button(frame_respuestas, text=opcion, command=lambda l=letra: verificar(l))
                btn.pack(pady=5, padx=20, fill=tk.X)
        else:
            entry_var = tk.StringVar()
            entry = ttk.Entry(frame_respuestas, textvariable=entry_var, font=("Helvetica", 12), justify="center")
            entry.pack(pady=10)
            entry.focus()
            
            btn_submit = ttk.Button(frame_respuestas, text="Responder", command=lambda: verificar(entry_var.get()))
            btn_submit.pack(pady=5)
            # Permitir presionar Enter para responder
            ventana_preg.bind('<Return>', lambda e: verificar(entry_var.get()))

    def mostrar_menu_victoria(self):
        puntos = len(self.preguntas_respondidas) * 10
        
        self.ventana_menu = tk.Toplevel(self.root)
        self.ventana_menu.title("¡Has Ganado!")
        self.ventana_menu.geometry("400x450")
        self.ventana_menu.configure(bg="#2C3E50")
        self.ventana_menu.transient(self.root)
        self.ventana_menu.grab_set()
        
        # Centrar ventana
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 200
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 225
        self.ventana_menu.geometry(f"+{x}+{y}")
        
        tk.Label(self.ventana_menu, text="🎉 ¡FELICIDADES! 🎉", font=("Helvetica", 18, "bold"), bg="#2C3E50", fg="#2ECC71").pack(pady=20)
        
        stats_text = f"Pasos Totales: {self.pasos}\nPreguntas: {len(self.preguntas_respondidas)}/{len(self.preguntas)}\nPuntuación Final: {puntos}"
        tk.Label(self.ventana_menu, text=stats_text, font=("Helvetica", 12), bg="#2C3E50", fg="white", justify="center").pack(pady=10)
        
        frame_botones = tk.Frame(self.ventana_menu, bg="#2C3E50")
        frame_botones.pack(pady=20, fill=tk.BOTH, expand=True)
        
        opciones = [
            ("🔄 Jugar de Nuevo", self.reiniciar_juego),
            ("🎬 Reproducir Replay", self.iniciar_replay),
            ("🧩 Ver Todas las Preguntas", self.mostrar_todas_preguntas),
            ("🗺️ Ver Mapa Completo", self.mostrar_mapa),
            ("❌ Salir", self.root.quit)
        ]
        
        for texto, comando in opciones:
            btn = ttk.Button(frame_botones, text=texto, command=comando)
            btn.pack(pady=5, padx=50, fill=tk.X)

    def reiniciar_juego(self):
        if hasattr(self, 'ventana_menu') and self.ventana_menu.winfo_exists():
            self.ventana_menu.destroy()
        self.reiniciar_variables()
        self.dibujar_laberinto()
        self.lbl_info.config(text="¡Juego reiniciado! Usa W, A, S, D para moverte.", fg="#BDC3C7")

    def iniciar_replay(self):
        if hasattr(self, 'ventana_menu') and self.ventana_menu.winfo_exists():
            self.ventana_menu.destroy()
            
        self.en_replay = True
        self.replay_idx = 0
        self.jugador_x, self.jugador_y = self.historial_movimientos[0]
        self.lbl_info.config(text="🎬 REPRODUCIENDO REPLAY... Por favor espera.", fg="#F1C40F")
        self.root.after(150, self.paso_replay)

    def paso_replay(self):
        if self.replay_idx < len(self.historial_movimientos):
            self.jugador_x, self.jugador_y = self.historial_movimientos[self.replay_idx]
            self.pasos = self.replay_idx
            self.dibujar_laberinto()
            self.replay_idx += 1
            self.root.after(150, self.paso_replay)
        else:
            self.en_replay = False
            self.lbl_info.config(text="✅ Replay finalizado.", fg="#2ECC71")
            # Volver a mostrar el menú de victoria tras 1 segundo
            self.root.after(1000, self.mostrar_menu_victoria)

    def mostrar_todas_preguntas(self):
        ventana = tk.Toplevel(self.root)
        ventana.title("Todas las Preguntas")
        ventana.geometry("600x500")
        ventana.configure(bg="#2C3E50")
        
        # Usar un Text widget con Scrollbar para mostrar la lista
        scrollbar = tk.Scrollbar(ventana)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        txt = tk.Text(ventana, bg="#34495E", fg="white", font=("Helvetica", 11), yscrollcommand=scrollbar.set, wrap=tk.WORD, padx=10, pady=10)
        txt.pack(expand=True, fill=tk.BOTH)
        scrollbar.config(command=txt.yview)
        
        txt.insert(tk.END, "--- LISTA DE PREGUNTAS ---\n\n")
        
        for idx, p in enumerate(self.preguntas):
            respondida = "✅ (Respondida)" if self.posicion_preguntas[idx] in self.preguntas_respondidas else "❌ (Sin responder)"
            pos = self.posicion_preguntas[idx]
            
            texto = f"Pregunta {idx+1} {respondida} - Pos: {pos}\n"
            texto += f"Q: {p['pregunta']}\n"
            
            if p["tipo"] == "opcion_multiple":
                respuesta = p['opciones'][ord(p['correcta'])-97]
            else:
                respuesta = p['respuesta']
                
            texto += f"R: {respuesta}\n"
            texto += "-" * 50 + "\n"
            
            txt.insert(tk.END, texto)
            
        txt.config(state=tk.DISABLED)

    def mostrar_mapa(self):
        # Cerramos temporalmente el menú si existe
        if hasattr(self, 'ventana_menu') and self.ventana_menu.winfo_exists():
            self.ventana_menu.destroy()
            
        self.dibujar_laberinto(modo_mapa=True)
        self.lbl_info.config(text="🗺️ Mostrando mapa con ID de preguntas. Cierra la ventana emergente para volver.", fg="#F1C40F")
        
        # Ventana para volver
        ventana = tk.Toplevel(self.root)
        ventana.title("Modo Mapa")
        ventana.geometry("250x100")
        ventana.configure(bg="#2C3E50")
        ventana.transient(self.root)
        ventana.grab_set()
        
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 125
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 50
        ventana.geometry(f"+{x}+{y}")
        
        def volver():
            ventana.destroy()
            self.dibujar_laberinto(modo_mapa=False)
            self.mostrar_menu_victoria()
            
        tk.Label(ventana, text="Modo Mapa Activado", bg="#2C3E50", fg="white", font=("Helvetica", 12)).pack(pady=10)
        ttk.Button(ventana, text="Volver al Menú", command=volver).pack()

if __name__ == "__main__":
    root = tk.Tk()
    
    # Estilos globales ttk
    style = ttk.Style()
    style.theme_use('clam')
    style.configure('TButton', font=('Helvetica', 11), padding=5)
    
    preguntas = []
    with open('preguntas.json', 'r') as f:
       preguntas = json.load(f)

    app = JuegoLaberintoGUI(root, preguntas)
    root.mainloop()
