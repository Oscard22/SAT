# Correr de manera simple
Instalar **python**, clonar el repositorio y ejecutar el programa con el siguiente comando:
```sh
python3 main.py
```


# Correr para desarrollo
Instalar las herramientas de desarrollo **envrc** y **guix**. Una vez que envrc este acomodado con tu shell, hay que correr los siguientes commandos en el repositorio clonado:
```sh
envrc allow

echo /path/to/repo >> ~/.config/guix/shell-authorized-directories 

cd ..

cd tkinter_game/
```
