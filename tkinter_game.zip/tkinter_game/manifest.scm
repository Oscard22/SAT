(use-modules (gnu packages))

(concatenate-manifests
 (list
  (specifications->manifest
   '("python"))))
